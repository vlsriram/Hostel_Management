

document.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
        document.querySelector('.loader-wrapper').style.display = 'none';
    }, 4000); // Adjust this time as needed
});


