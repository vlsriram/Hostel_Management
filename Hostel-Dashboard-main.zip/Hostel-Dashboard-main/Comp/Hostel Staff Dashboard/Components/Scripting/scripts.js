function viewDetails(complaintId) {
    // Example function to handle the view details action
    // Redirect to the complaint details page or open a modal
    window.location.href = `Complaint-Details.html?id=${complaintId}`;
}
